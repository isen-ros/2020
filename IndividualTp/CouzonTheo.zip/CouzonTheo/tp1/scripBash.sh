mkdir example
cd example
touch CouzonTheo.txt
echo "ROSS Navigation Class" >> CouzonTheo.txt

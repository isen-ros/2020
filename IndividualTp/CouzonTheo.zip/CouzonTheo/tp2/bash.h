#!/bin/bash
xterm -e roslaunch turtle_c turtlemimic.launch &
xterm -e rosrun turtle_c penHue
xterm -e rosrun turtle_c TurtleSqare

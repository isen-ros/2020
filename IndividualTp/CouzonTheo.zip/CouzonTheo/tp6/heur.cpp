#include "ros/ros.h"
#include "tp6/serveur.h"
#include "stdio.h"
#include "time.h"

bool add(tp6::serveur::Request &req, tp6::serveur::Response &res)
{
    time_t sec;
    struct tm instant;

    time(&sec);
    instant = *localtime(&sec);

    res.horaire = instant.tm_hour;
    res.horaire1 = instant.tm_min;
    res.horaire2 = instant.tm_sec;

    ROS_INFO("Info envoyée");
    return true;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "heure");
    ros::NodeHandle n;
    time_t sec;
    ros::ServiceServer service = n.advertiseService("serveur", add);
    ROS_INFO("Bon");
    ros::spin();
    return 0;
}
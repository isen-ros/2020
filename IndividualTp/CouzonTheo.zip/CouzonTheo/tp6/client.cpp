#include "ros/ros.h"
#include "tp6/serveur.h"
#include <cstdlib>

int main(int argc, char **argv)
{
    ros::init(argc, argv, "client");
    ros::NodeHandle n;
    ros::ServiceClient client = n.serviceClient<exercice6::serveur>("serveur");
    tp6::serveur serv;
    serv.request.a = 0;

    do
    {
        if (client.call(srv))
        {
            ROS_INFO("Heure => [%ld] : [%ld] : [%ld]", (long int)serv.response.horaire, serv.response.horaire1, serv.response.horaire2);
        }
        else
        {
            ROS_ERROR("Erreur");
            return 1;
        }
        ros::Duration(1).sleep();
    } while (ros::ok());
    return 0;
}